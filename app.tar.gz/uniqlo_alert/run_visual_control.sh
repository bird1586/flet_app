nohup python3 ~/project/web/uniqlo_alert/visual_control.py >/dev/null 2>&1 &
