
from requests_html import HTMLSession
import requests
import redis    


def notify(msg, sticker=None, picURI=None, pic=None):
    headers = {
        "Authorization": "Bearer " + "Gp95lV601fy5GryBhAPE2ijvdQNpTKQBQsoQYww1mXo" 
							} 
    
    payload = {'message': msg}
    if sticker:
        payload["stickerPackageId"] = sticker[0]
        payload["stickerId"] = sticker[1]
    if picURI:
        payload["imageThumbnail"] = picURI
        payload["imageFullsize"] = picURI
    if pic:
        pic = {'imageFile': pic}
    
    r = requests.post("https://notify-api.line.me/api/notify",
                    headers = headers,
                    params = payload,
                    files=pic)
    return r.status_code


r = redis.Redis(host='localhost', port=6379, db=0) 
buy_list = eval(r.get("uniqlo_buy_list").decode())

session = HTMLSession()
for name, url in buy_list.items():
    
    res = session.get(url)
    now_price = res.html.find("div .four.wide.column h2")
    now_price = int(now_price[0].text.replace("$", ''))
    
    history_price = res.html.find("div .ts.medium.statistic .value")
    history_price = dict(zip(['high', 'low'], [int(p.text) for p in history_price]))

    print(name, now_price)
    print(history_price)
    
    cond1 = (now_price != history_price['high'] )
    cond2 = (now_price == history_price['low'] )
    if cond1 and cond2:
        notify(f"{name}最低價囉，只要{now_price}")


