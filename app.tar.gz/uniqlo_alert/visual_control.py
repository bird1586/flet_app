from flask import Flask, render_template, request, redirect
import redis

r = redis.Redis(host='localhost', port=6379, db=0) 
app = Flask(__name__)

@app.route('/')
def index():
    urls = []
    buy_list = eval(r.get("uniqlo_buy_list").decode())
    for name, url in buy_list.items():
        urls.append({"url": url, "name":name})
    return render_template('index.html', urls=urls)

@app.route('/do_something', methods=['POST'])
def do_something():
    name = request.form.get('name')
    name_entry = request.form.get('name_entry')
    text_entry = request.form.get('text_entry')
    buy_list = eval(r.get("uniqlo_buy_list").decode())
    
    if name:
        del buy_list[name]
        r.set("uniqlo_buy_list", str(buy_list))
        return redirect('/', code=303)

    if text_entry:
        buy_list[name_entry] = text_entry
        r.set("uniqlo_buy_list", str(buy_list))
        return redirect('/', code=303)

    return 'No action performed'

if __name__ == '__main__':
    app.run("0.0.0.0", debug=True)

